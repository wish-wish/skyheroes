**Project Description**
This is a simple implementation of offline navigation for windows phone 7 with map offset adjustment support.

[Map control that supports offline tiles](http://hi.baidu.com/coolypf/item/cb4c78d83d5bd619d78ed0fe)
[How to adjust map offset](http://blog.csdn.net/coolypf/article/details/8686588) ([Previous method](http://hi.baidu.com/coolypf/item/a5f05188c21d60874414cffe))

**Project Owner's Blog**
 [http://blog.csdn.net/coolypf](http://blog.csdn.net/coolypf)

**Map data for offline navigation**
* Customize offline map data
	* Download map tiles with [this tool](http://blog.csdn.net/coolypf/article/details/8563894) or [this tool](http://www.wpxap.com/thread-138142-1-1.html) ([alternative download](https://on4wp7.codeplex.com/downloads/get/404437))
	* Create offline map data file with [the generator](https://on4wp7.codeplex.com/SourceControl/changeset/view/15246#252182)
* OR use [pre-generated offline map data file](https://on4wp7.codeplex.com/downloads/get/404440)
* Use _Isolated Storage Explorer Tool_ to upload offline map data file to WP7 device (root directory of the Isolated Storage)