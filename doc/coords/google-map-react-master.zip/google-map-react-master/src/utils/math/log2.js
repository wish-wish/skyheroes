const log2 = Math.log2 ? Math.log2 : x => Math.log(x) / Math.LN2;

export default log2;
