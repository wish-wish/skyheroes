import GoogleMap from './google_map';

module.exports = GoogleMap;
