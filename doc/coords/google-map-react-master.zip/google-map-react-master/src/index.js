export default from './google_map';
