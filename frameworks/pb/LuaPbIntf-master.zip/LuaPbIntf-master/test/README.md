# How to run test

1. Build luapbintf.dll
	* Results ../premake/vs2015/bin/x32/Debug/luapbintf.dll
1. Copy luapbintf.dll
1. Copy lua53.exe lua53.dll
1. Run test
```
lua53.exe test.lua
```
