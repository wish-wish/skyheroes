# Todo

* support *.proto reload
* make error string more meaningful
* Switch to conan build. Delete third_party and update Dockerfile.