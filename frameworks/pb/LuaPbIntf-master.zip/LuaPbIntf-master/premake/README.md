## To generate VS solution and Linux make file

1. Download premake5.exe here.
1. Run premake5.bat.
