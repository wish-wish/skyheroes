Copy linux lib here or install to system:
* libprotobuf.a
* lua.a
