Copy windows debug lib here:
* libprotobufd.lib
* lua.lib
