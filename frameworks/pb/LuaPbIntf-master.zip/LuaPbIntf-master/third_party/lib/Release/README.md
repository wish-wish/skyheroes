Copy windows release lib here:
* libprotobuf.lib
* lua.lib
