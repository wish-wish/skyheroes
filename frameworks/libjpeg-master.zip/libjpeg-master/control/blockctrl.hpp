/*************************************************************************

    This project implements a complete(!) JPEG (10918-1 ITU.T-81) codec,
    plus a library that can be used to encode and decode JPEG streams. 
    It also implements ISO/IEC 18477 aka JPEG XT which is an extension
    towards intermediate, high-dynamic-range lossy and lossless coding
    of JPEG. In specific, it supports ISO/IEC 18477-3/-6/-7/-8 encoding.

    Copyright (C) 2012-2017 Thomas Richter, University of Stuttgart and
    Accusoft.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*************************************************************************/
/*
** This class defines the minimal abstract interface the block based
** scan types require to access quantized data.
**
** $Id: blockctrl.hpp,v 1.9 2016/10/28 13:58:53 thor Exp $
**
*/

#ifndef CONTROL_BLOCKCTRL_HPP
#define CONTROL_BLOCKCTRL_HPP

/// Includes
#include "tools/environment.hpp"
///

/// Forwards
class QuantizedRow;
class Scan;
///

/// class BlockCtrl
// This class defines the minimal abstract interface the block based
// scan types require to access quantized data.
class BlockCtrl : public JKeeper {
  //
public:
  BlockCtrl(class Environ *env)
    : JKeeper(env)
  { }
  //
  virtual ~BlockCtrl(void)
  { }
  //
  //
  // Return the current top MCU quantized line.
  virtual class QuantizedRow *CurrentQuantizedRow(UBYTE comp) = 0;
  //
  // Start a MCU scan by initializing the quantized rows for this row
  // in this scan.
  virtual bool StartMCUQuantizerRow(class Scan *scan) = 0;
  //
  // Make sure to reset the block control to the
  // start of the scan for the indicated components in the scan, 
  // required after collecting the statistics for this scan.
  virtual void ResetToStartOfScan(class Scan *scan) = 0;
  //
};
///

///
#endif
