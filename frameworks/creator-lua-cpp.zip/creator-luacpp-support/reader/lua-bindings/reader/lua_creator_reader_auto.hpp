#include "base/ccConfig.h"
#ifndef __creator_reader_h__
#define __creator_reader_h__

#ifdef __cplusplus
extern "C" {
#endif
#include "tolua++.h"
#ifdef __cplusplus
}
#endif

int register_all_creator_reader(lua_State* tolua_S);






























#endif // __creator_reader_h__
